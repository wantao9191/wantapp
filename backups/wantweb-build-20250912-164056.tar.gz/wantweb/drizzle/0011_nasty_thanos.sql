ALTER TABLE "care_packages" ADD COLUMN "min_duration" integer;--> statement-breakpoint
ALTER TABLE "care_packages" ADD COLUMN "max_duration" integer;