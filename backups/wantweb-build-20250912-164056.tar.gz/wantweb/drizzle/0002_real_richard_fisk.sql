ALTER TABLE "organizations" ADD COLUMN "operator" varchar(50);--> statement-breakpoint
ALTER TABLE "organizations" ADD COLUMN "setup_time" timestamp;