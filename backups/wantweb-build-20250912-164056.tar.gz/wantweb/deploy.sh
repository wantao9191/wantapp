#!/bin/bash

# 服务器部署脚本
set -e

echo "🚀 开始部署..."

# 检查环境
if ! command -v pnpm &> /dev/null; then
    echo "❌ 错误：未安装 pnpm"
    exit 1
fi

if ! command -v pm2 &> /dev/null; then
    echo "❌ 错误：未安装 PM2"
    exit 1
fi

# 使用生产环境 package.json 并安装依赖
echo "📥 使用生产环境配置安装依赖..."
cp package.prod.json package.json
pnpm install --frozen-lockfile

# 检查环境配置
if [ ! -f ".env.production.local" ]; then
    echo "⚠️  警告：未找到 .env.production.local 文件"
    echo "请复制 .env.production.local.template 为 .env.production.local 并配置"
    exit 1
fi

# 启动数据库（如果存在 docker-compose 文件）
if [ -f "docker-compose.db.yml" ]; then
    echo "🗄️  启动数据库..."
    docker-compose -f docker-compose.db.yml up -d
    sleep 10
fi

# 数据库迁移（可选）
if [ -f "drizzle.config.ts" ]; then
    echo "🔄 运行数据库迁移..."
    
    # 检查并安装缺失的依赖
    echo "📦 检查数据库迁移依赖..."
    if ! pnpm list dotenv > /dev/null 2>&1; then
        echo "📥 安装 dotenv 依赖..."
        pnpm add dotenv
    fi
    
    # 确保环境变量文件存在
    if [ ! -f ".env.production.local" ]; then
        echo "⚠️  未找到 .env.production.local 文件"
        echo "   请先配置环境变量文件"
        echo "   跳过数据库迁移"
    else
        # 设置生产环境变量
        export NODE_ENV=production
        
        if pnpm db:migrate; then
            echo "✅ 数据库迁移成功"
            echo "🔄 运行数据库种子数据..."
            if pnpm db:seed; then
                echo "✅ 数据库种子数据成功"
            else
                echo "⚠️  数据库种子数据失败，跳过此步骤"
            fi
        else
            echo "⚠️  数据库迁移失败，跳过此步骤"
            echo "   如果数据库结构无变化，可以忽略此错误"
        fi
    fi
else
    echo "⚠️  未找到 drizzle.config.ts，跳过数据库迁移"
fi

# 启动应用
echo "🚀 启动应用..."
pm2 start ecosystem.config.js
pm2 startup
pm2 save

echo "✅ 部署完成！"
echo "查看状态: pm2 status"
echo "查看日志: pm2 logs wantweb"
