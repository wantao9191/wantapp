# 部署说明

## 服务器环境要求
- Node.js 18+
- pnpm
- PM2
- Docker & Docker Compose
- Nginx

## 部署步骤

### 1. 上传到服务器
```bash
scp wantweb-build-*.tar.gz root@your-server:/www/wwwroot/
```

### 2. 解压和安装
```bash
cd /www/wwwroot
tar -xzf wantweb-build-*.tar.gz
cd wantweb
pnpm install --frozen-lockfile --production
```

### 3. 配置环境变量
```bash
cp .env.production.local.template .env.production.local
# 编辑 .env.production.local 文件，填入正确的配置
# 使用 vi 编辑器（大多数 Linux 系统都有）
vi .env.production.local
```

### 4. 启动数据库
```bash
docker-compose -f docker-compose.db.yml up -d
```

### 5. 数据库迁移（可选）
```bash
# 如果数据库结构有变化，运行迁移
pnpm db:migrate

# 如果需要初始化数据，运行种子
pnpm db:seed
```

### 6. 启动应用
```bash
pm2 start npm --name "wantweb" -- start
pm2 startup
pm2 save
```

### 7. 配置 Nginx
```bash
# 复制 Nginx 配置
cp nginx.conf /etc/nginx/sites-available/wantweb

# 编辑配置（修改域名和路径）
vi /etc/nginx/sites-available/wantweb

# 启用配置
ln -s /etc/nginx/sites-available/wantweb /etc/nginx/sites-enabled/

# 测试配置
nginx -t

# 重载 Nginx
systemctl reload nginx
```

## 更新部署
```bash
# 停止应用
pm2 stop wantweb

# 解压新版本
cd /www/wwwroot
tar -xzf wantweb-build-*.tar.gz
cd wantweb
pnpm install --frozen-lockfile --production

# 重启应用
pm2 restart wantweb
```

## 监控命令
```bash
pm2 status
pm2 logs wantweb
pm2 monit
```
